# import erteke
# import sorozat
import pogyasz1
# erteke.fel1()
# sorozat.fel2()
pogyasz1.fel3()
