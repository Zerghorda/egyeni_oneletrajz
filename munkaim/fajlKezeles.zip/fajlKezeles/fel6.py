
def fel6():
    print("6. feladat: 	Ha egy sorban egy mondat van, ha másképp töri a böngésződ, akkor alakítsd át a kiírást!\n")
    f = open("dalszoveg", "r")
    print(f.read())

