def fel7():
    print("7. feladat: 	Olvasd be a fájlt és írd ki a sorait fordított sorrendben, a képernyőre csakúgy, mint egy fájlba!")
    f = open("dalszoveg", "r")
    dalhossz = len(f)

